function [F, W, V, vargradV] = locexpsvi_sigmoidbeliefnet1(W, V, Y, options)
%
%

recognModel = options(9);

[N, D] = size(Y);
tildeY = Y; 
tildeY(tildeY==0)=-1;
Yplusone = [ones(N,1), Y];

[K Dplus1] = size(V); 
if recognModel == 1
   if Dplus1~=(D+1)
      error('V must have D+1 columns to account also for the bias');
   end
else
   K = size(V,2); 
end

[D Kplus1] = size(W); 

if Kplus1~=(K+1)
    error('W must have K+1 columns to account also for the bias');
end

row = options(2);    % Learning rate for W
rov = options(3);    % Learning rate for V

if recognModel == 1
   % Nx(D+1) times (D+1)xK 
   YV = Yplusone*V';
   % variational distribution 
   Q = sigmoid(YV); 
else
   Q = sigmoid(V);
end
    
QQ = Q.*(1-Q); 
    
logQterm = log(1-Q + (Q==1)) - log(Q + (Q==0));   
    
% draw a global/pivot sample from the variational distribution 
X = double((rand(N,K) < Q));
    
% compute the pivot inputs to the model sigmoid functions (actually the log(1 + exp()))
% Nx(K+1) times (K+1)*D
X = [ones(N,1), X];
XW = X*W';
    
YF = -tildeY.*XW;
m = max(0,YF); 
ginit = sum(m + log( exp(-m) + exp( YF - m )), 2);
 
g = zeros(N,K);
for k=2:K+1 
%    
    indzero = find(X(:,k)==0);
    indone = find(X(:,k)==1);

    XWflip = XW + (1 - 2*X(:,k))*W(:,k)';    
    YF = -tildeY.*XWflip;
    m = max(0,YF); 
    gflip = sum(m + log( exp(-m) + exp( YF - m )), 2);
                      
    g(indzero,k-1) = ginit(indzero) - gflip(indzero);
    g(indone,k-1) = gflip(indone) - ginit(indone);
%    
end
    
if recognModel == 1
    dV = (QQ.*(g + logQterm))'*Yplusone;    
else
    dV = (QQ.*(g + logQterm));
end
     
% store the variance of the first gradient component of V
% (useful if you wish to investigate variance reduction issues)
vargradV = dV(1,1);
    
% Derivatives wrt model parameters W 
dW = (Y - sigmoid(XW))'*X;
  
% Update parameters 
W = W + row*dW;  
V = V + rov*dV; 

% Compute instantaneous lower bound  
YF = -tildeY.*XW;
m = max(0,YF); 
% instantaneous value of the lower bound 
F = - sum( sum(m + log( exp(-m) + exp( YF - m )) )) + (N*K)*log(0.5) - sum(sum( (1-Q).*log(1-Q + (Q==1)) + Q.*log(Q + (Q==0)) ));   
F = F/N;