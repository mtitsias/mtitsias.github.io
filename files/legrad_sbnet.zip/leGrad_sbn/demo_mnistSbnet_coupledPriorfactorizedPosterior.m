
clear;
close all;
outdir= '../diagrams/';
iters = 50000;      % number of optimization iterations
eta = 0.005;        % initial learning rate 
dec = 0.95;         % decrease the learing rate by this amount after each optimization step
plotResults = 1;
recognModel = 1;    % use a recognition model or not for a variational distribution 
                    % (recognModel=0 makes sense only if numBatch is equal to the full size of the data)
K = 200;            % number of hidden units  in the sigmoid net
numBatch = 100;     % how many data 
changeLRateEvery = 5000; 


randn('seed',1);
rand('seed',1);

% START READING DATA 
Y = load('../../../DATA/ml_datasets/binarized_mnist/binarized_mnist_train.amat');
[N, D] = size(Y);
%%  END READING DATA 


options = zeros(1,10);
options(2) = eta;          % learning rate for parameters W 
options(3) = eta;          % learning rate for parameters A 
options(4) = 0.1*eta;      % learning rate for parameters V 
options(9) = recognModel;

% initialize likelihood parameters of p(y|x)
W = (0.8/sqrt(K+1))*randn(D,K+1); 

% initialize fully connected prior parameters p(x)
lowerMask = triu(ones(K))';
A = repmat(0.8./sqrt(1:K)', 1, K).*randn(K,K);
%A = (1/sqrt(K))*randn(K,K);
A = A.*lowerMask; 

% initialize variational parameters 
if recognModel == 1
   V = zeros(K,D+1);
else
   V = zeros(N,K); 
end


F = zeros(1,iters);
gradV = zeros(1,iters);
tic;
perm = randperm(N);
st = 1;
for it=1:iters
%  
   % take a minibatch 
   if (st+numBatch-1) <= N
      block = perm(st:st+numBatch-1);
      st = st+numBatch;
   else
      st = 1; 
      perm = randperm(N);
      block = perm(st:st+numBatch-1);
      st = st+numBatch;
   end
         
   [F(it), W, A, V, gradV(it)] = locexpgrad_sigmoidbeliefnet2(W, A, V, Y(block,:), options);

   if mod(it,changeLRateEvery) == 0
     % decrease the learning rate for the next stage 
     options(2) = dec*options(2);
     options(3) = dec*options(3);
     options(4) = dec*options(4);
     options(4)
   end
   
   if mod(it,100)==0
     fprintf('Iters=%d,Ft=%f\n',it,F(it));
   end
%   
end
timetaken = toc; 

% Prediction
T = 1000;     
% Compute lower bound in the log likelihood in the test data     
Ytest = load('../../../DATA/ml_datasets/binarized_mnist/binarized_mnist_test.amat');
Ntest = size(Ytest,1); 
tildeYtest = Ytest; 
tildeYtest(tildeYtest==0)=-1;
Ytestplusone = [ones(Ntest,1), Ytest];
YV = Ytestplusone*V'; 
Qtest = sigmoid(YV); 
entropy = - sum( (1-Qtest).*log(1-Qtest + (Qtest==1)) + Qtest.*log(Qtest + (Qtest==0)), 2); 
Ftest = zeros(Ntest,1); 
for t=1:T 
   X = double( (rand(Ntest,K) < Qtest) );
   tildeX = X; 
   tildeX(tildeX==0)=-1;
   X = [ones(Ntest,1), X];
   XW = X*W';
   
   YF = -tildeYtest.*XW;  
   m = max(0,YF); 
   Ftest = Ftest - sum(m + log( exp(-m) + exp( YF - m )), 2);
   XA = X(:,1:K)*A';   
   XF = -tildeX.*XA;
   m = max(0,XF); 
   Ftest = Ftest - sum(m + log( exp(-m) + exp( XF - m )), 2);
end
Ftest = Ftest/T + entropy; 

disp(['Prediction negative log likelihood: ' num2str(-mean(Ftest))]);

if plotResults 
    
%visualize weights
figure;
visualize(W(:,2:end))

figure; 
visualize(V(:,1:end-1)')

%visualize data
figure;
perm = randperm(N); 
Nplot = 100;
for ii=1:Nplot
    i = perm(ii); 
    subtightplot(ceil(sqrt(Nplot)),ceil(sqrt(Nplot)),ii);     
    imagesc(reshape(Y(i,:),28,28)');
    axis off;
    colormap('gray');     
end


% plot also the reconstruction of the digits 
if recognModel == 1
   % Nx(D+1) times (D+1)xK 
   YV = [ones(N,1), Y]*V';
   % variational distribution 
   Q = sigmoid(YV);
else
   Q = sigmoid(V);
end
X = round(Q); %(rand(N,K) < Q);    
X = [ones(N,1), X];
figure;
%title('Reconstructed Data')
S = sigmoid(X*W');
for ii=1:Nplot
    i = perm(ii); 
    subtightplot(ceil(sqrt(Nplot)),ceil(sqrt(Nplot)),ii);     
    imagesc(reshape(S(i,:),28,28)');
    axis off;
    colormap('gray');     
end


% generate digits
Ngen = 100; 
Xsample = zeros(Ngen,K);
for n=1:Ngen
   for k=1:K 
      Xprev = [1 Xsample(n, 1:k-1)];  
      Xsample(n,k) = double((rand < sigmoid((A(k,1:k)*Xprev')) )); 
   end
end   
Xsample = [ones(Ngen,1), Xsample];
S = sigmoid(Xsample*W');
figure;
for i=1:Ngen
   subtightplot(ceil(sqrt(Ngen)),ceil(sqrt(Ngen)),i);     
   imagesc(reshape(S(i,:),28,28)');
   axis off;
   colormap('gray');     
end


end 

%save sigmoidnet_resCoupledPriorFactorizedPost Ftest F W A V eta dec recognModel K N numBatch changeLRateEvery iters timetaken; 


