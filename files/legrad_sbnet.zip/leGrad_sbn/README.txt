This MATLAB software implements the local expectation gradients
algorithm for sigmoid belief nets with fully factorized prior p(x)
or a fully connected prior over the hidden units.  

Michalis K. Titsias and Miguel Lazaro-Gredilla. 
Local Expectation Gradients for Black Box Variational Inference, NIPS, 28, 2015. 

The main routines are the functions locexpgrad_sigmoidbeliefnet1.m (sigmoid belief net with factorized/uniform prior)
and locexpgrad_sigmoidbeliefnet2.m (fully coupled and learnable prior). For both these cases the likelihood is always
factorized given the hidden units. 

Also the variational distribution is factorized across the hidden units and can be defined by a linear recognition model.

You can freely use this code for academic or research purposes 
as long as you refer to the above publication.  

Copyright (c) Michalis Titsias (2015)

