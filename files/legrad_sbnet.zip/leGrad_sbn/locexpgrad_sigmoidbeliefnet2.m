function [F, W, A, V, gradV] = locexpsvi_sigmoidbeliefnet2(W, A, V, Y, options)
%
%


recognModel = options(9);

[N, D] = size(Y);
tildeY = Y; 
tildeY(tildeY==0)=-1;
Yplusone = [ones(N,1), Y];

[K Dplus1] = size(V); 
if recognModel == 1
   if Dplus1~=(D+1)
      error('V must have D+1 columns to account also for the bias');
   end
else
   K = size(V,2); 
end

[D Kplus1] = size(W); 

if Kplus1~=(K+1)
    error('W must have K+1 columns to account also for the bias');
end

row = options(2);    % Learning rate for W
roa = options(3);    % Learning rate for A
rov = options(4);    % Learning rate for V

roaK = roa./sqrt(1:K);
roaK = repmat(roaK(:), 1, K);


% lower triangular mask 
lowerMask = triu(ones(K))';

if recognModel == 1
   % Nx(D+1) times (D+1)xK 
   YV = Yplusone*V';
   % variational distribution 
   Q = sigmoid(YV); 
else
   Q = sigmoid(V);
end
    
QQ = Q.*(1-Q); 
    
logQterm = log(1-Q + (Q==1)) - log(Q + (Q==0));   
    
% draw a global/pivot sample from the variational distribution 
X = double((rand(N,K) < Q));
tildeX = X; 
tildeX(tildeX==0)=-1;  
    
% compute the pivot inputs to the model sigmoid functions (actually the log(1 + exp()))
% Nx(K+1) times (K+1)*D
X = [ones(N,1), X];
XW = X*W';
YF = -tildeY.*XW;
m = max(0,YF); 
ginit = sum(m + log( exp(-m) + exp( YF - m )), 2);
 
% Do now similar computations for the prior term 
XA = X(:,1:K)*A';   % N x K matrix with values that are in the sigmoids in p(x_k|x_1,...,x_{k-1}) 
XF = -tildeX.*XA;
m = max(0,XF); 
    
finit = m + log( exp(-m) + exp( XF - m ));
finit = sum(finit,2)*ones(1,K)  - cumsum(finit, 2); 
%finit = m + log( exp(-m) + exp( XF - m ));
    
g = zeros(N,K); 
f = zeros(N,K);
for k=2:K+1 
%    
    indzero = find(X(:,k)==0);
    indone = find(X(:,k)==1);

    % This prepares the contribution coming from the likelihood p(y|x)
    XWflip = XW + (1 - 2*X(:,k))*W(:,k)';    
    YF = -tildeY.*XWflip;
    m = max(0,YF); 
    gflip = sum(m + log( exp(-m) + exp( YF - m )), 2);  
    if ~isempty(indzero) > 0
       g(indzero,k-1) = ginit(indzero) - gflip(indzero);
    end
    if ~isempty(indone)
       g(indone,k-1) = gflip(indone) - ginit(indone);
    end
           
    % This prepares the contribution coming from the prior p(x)
    f(:,k-1) = XA(:,k-1); 
    if k < (K+1)
    %      
        XAflip = XA(:,k:end) + (1 - 2*X(:,k))*A(k:end, k)';  
        XF = -tildeX(:,k:end).*XAflip;
        m = max(0,XF); 
        fflip = sum(m + log( exp(-m) + exp( XF - m )), 2);
       
        if ~isempty(indzero) > 0
           %f(indzero,k-1) = f(indzero,k-1) + sum( finit(indzero, k:end),2) - fflip(indzero);
           f(indzero,k-1) = f(indzero,k-1) + finit(indzero,k-1) - fflip(indzero);
        end
        if ~isempty(indone)
           %f(indone,k-1)  = f(indone,k-1)  + fflip(indone) -  sum( finit(indone, k:end),2);
           f(indone,k-1)  = f(indone,k-1)  + fflip(indone) -  finit(indone, k-1);
        end         
        %   
    end
    %    
end
    
% This just for debugging 
% f1 = temporary(A, X); 
% ff = temporary2(A, X);
% save ok f f1 ff X A; 
% fg = ghhhk;
    
if recognModel == 1
   dV = (QQ.*(g + f + logQterm))'*Yplusone;    
else
   dV = (QQ.*(g + f + logQterm));
end
     
% store the first gradient component
gradV = dV(1,1);

% Derivatives wrt likelihood p(y|x) parameters W 
dW = (Y - sigmoid(XW))'*X;
  
% Derivatives wrt prior p(x) parameters A 
dA = (X(:,2:end) - sigmoid(XA))'*X(:,1:K); 
dA = dA.*lowerMask;
    
% Update parameters 
W = W + row*dW;  
%A = A + roa*dA;
A = A + roaK.*dA;

V = V + rov*dV; 
    
% Compute the instantaneous value of the lower bound  
YF = -tildeY.*XW;
m = max(0,YF); 
F = - sum( sum(m + log( exp(-m) + exp( YF - m )) ));
%XA = X(:,1:K)*A';   % N x K matrix with values that are in the sigmoids in p(x_k|x_1,...,x_{k-1}) 
XF = -tildeX.*XA;
m = max(0,XF); 
F = F - sum( sum(m + log( exp(-m) + exp( XF - m )) )) - sum(sum( (1-Q).*log(1-Q + (Q==1)) +  Q.*log(Q + (Q==0)) ));  
 F = F/N;



function f = temporary(A, X) 
%

N = size(X,1); 
K = size(A,1);

XX = X;

f = zeros(N,K);
for k=2:K+1
%  
   X = XX; 
   X(:,k) = 0;
   tildeX = X(:,2:end); 
   tildeX(tildeX==0)=-1;

   % Do now similar computations for the prior term  
   XA = X(:,1:K)*A';  % N x K matrix with values that are in the sigmoids in p(x_k|x_1,...,x_{k-1}) 
   XF = -tildeX.*XA;
   m = max(0,XF); 
   f(:,k-1) = sum(m + log( exp(-m) + exp( XF - m )), 2);
   
   X = XX; 
   X(:,k) = 1;
   tildeX = X(:,2:end); 
   tildeX(tildeX==0)=-1;

   % Do now similar computations for the prior term  
   XA = X(:,1:K)*A';   % N x K matrix with values that are in the sigmoids in p(x_k|x_1,...,x_{k-1}) 
   XF = -tildeX.*XA;
   m = max(0,XF); 
   f(:,k-1) =  f(:,k-1) - sum(m + log( exp(-m) + exp( XF - m )), 2);
%
end




function f = temporary2(A, X) 
%

N = size(X,1); 
K = size(A,1);

XX = X(:,2:end); 
ff = zeros(N,K);
for n=1:N
%    
   for k=1:K
      XX = X(:,2:end);    
      Xprev = [1 XX(n, 1:k-1)];
      ff(n, k) = log(1 + exp( A(k,1:k)*Xprev' ) ) - log(1 + exp( - A(k,1:k)*Xprev' ) );
       
      XX(n, k) = 0; 
      for ell=(k+1):K
         Xprev = [1 XX(n, 1:ell-1)];
         tildeX = XX(n, ell);
         tildeX(tildeX==0)=-1;
         ff(n, k) = ff(n, k) + log(1 + exp( - tildeX*(A(ell,1:ell)*Xprev')  ) );
      end
      
      
      XX(n, k) = 1; 
      for ell=(k+1):K 
         Xprev = [1 XX(n, 1:ell-1)];
         tildeX = XX(n, ell);
         tildeX(tildeX==0)=-1;
         ff(n, k) = ff(n, k) - log(1 + exp( - tildeX*(A(ell,1:ell)*Xprev')  ) );
      end
   end
%   
end


