
% illustration in 1-d classification

dataName = 'binaryclassToy';
expNo = 1;
storeRes = 0;


% CREATE DATA 
N = 200;
% simple exponential kernel 
sigmaf = 1; % kernel variance   
sigma2 = 0.03^2; % noise variance
ell2 = 0.01; % lengthscale
D = 1;
% randomly generate input data 
X = rand(N,D); 
X = sort(X);  
gptmp.logtheta = [log(ell2) log(sigmaf)];
Knn = kernCompute(gptmp, X, X);
F = gaussianSample(1, zeros(1,N), Knn);
Y = F(:) + sqrt(sigma2)*randn(N,1);
Y(Y<0)=-1;
Y(Y>=0)=1;

% model options
options = gpsampOptions('classification'); 

% create the model
model = gpsampCreate(Y, X, options);

mcmcoptions = mcmcOptions('controlPnts');
mcmcoptions.adapt.incrNumContrBy = 1;
% adaption phase
[model PropDist samples accRates] = gpsampControlAdapt(model, mcmcoptions.adapt);
% training/sampling phase
[model PropDist samples accRates] = gpsampControlTrain(model, PropDist, mcmcoptions.train);

if storeRes == 1
    d = date; 
    save(['dem' dataName num2str(experimentNo) d '.mat'], 'model', 'PropDist','samples','accRates');
end

% plot the samples
gpsampPlot(model, samples);
