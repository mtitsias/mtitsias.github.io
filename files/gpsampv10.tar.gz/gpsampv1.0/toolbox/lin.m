function fx = lin(x)
%

fx = x;
