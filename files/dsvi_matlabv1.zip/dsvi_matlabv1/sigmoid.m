function s = sigmoid(z)
%function s = sigmoid(z)
%  

s = 1./(1 + exp(-z) ); 
