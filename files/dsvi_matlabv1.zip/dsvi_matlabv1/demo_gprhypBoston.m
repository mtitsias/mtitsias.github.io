clear;
close all;
addpath toolbox_gpml;
outdir= '../../diagrams/';
dataName = 'Boston';
randn('seed',0);
rand('seed',0);

load data/boston.mat;    

% log likelihood function
covfunc = {'covSum', {'covSEard','covNoise'}};
loglik.name = @log_gpr;    % log marginal likelghiood of gp regression 
loglik.inargs{1} = covfunc;
loglik.inargs{2} = X;
loglik.inargs{3} = y;

D = size(X,2);

% log prior
logprior.name = @log_normal;  % prior over the hyperparameters
logprior.inargs{1} = zeros(D+2,1);  % mean of the prior
logprior.inargs{2} = 10*ones(D+2,1); % variances of the prior

dec = 0.95; 

options = zeros(1,10); 
options(1) = 1000;             % number of iterations per state 
options(2) = 0.5/size(X,1);    % initial value of learning rate
 
options(4) = 1;   % (1 - Gaussian standard distribution)  (1 - Gaussian standard distribution)

mu = zeros(D+2,1);
C = eye(D+2);
%C = ones(D+2,1);

iters = 20;  % number of optimization stages (each stage takes options(1) iterations)

F = zeros(1,iters*options(1));
tic;
for it=1:iters
%    
   [Ftmp, mu, C] = dsvi(mu, C, loglik, logprior, options);
   
   F((it-1)*options(1)+1:it*options(1)) = Ftmp;
   
   % decrease the learning rate for the next stage 
   options(2) = dec*options(2);
   
   fprintf('Iters=%d,Ftmp=%f\n',it*options(1),mean(Ftmp));
%   
end
timetakenVar = toc;

disp('Stochastic variational is completed.'); 

vars = diag(C*C'); 

% LOWER BOUND
mF = zeros(1,length(F));
W = 200;
for n=1:length(F)
    st = n-W+1;
    st(st<1)=1;
    mF(n) = mean(F(st:n));
end
figure;
plot(mF,'b', 'linewidth',2);
xlabel('Iterations','fontsize',20);
ylabel('Lower bound','fontsize',20);
set(gca,'fontsize',20);
if exist(outdir)
   print('-depsc2', '-r300', [outdir 'boston_lowerBound']);
   cmd = sprintf('epstopdf %s', [outdir 'boston_lowerBound.eps']);
   system(cmd);
end

[D, D2] = size(C);
if D2 == 1
    diagfull = 'diag'; 
elseif D2 == D
    diagfull = 'full';
end

% COMPARISON WITH EMPIRICAL ESTIMATES OBTAINED BY MCMC
N = 40;
for d=1:14
  figure;
  hold on;
  set(gcf, 'Renderer', 'Painters');
  bins = linspace(min(sampl.kernLogtheta(:,d)), max(sampl.kernLogtheta(:,d)), N+1);
  [h, x] = hist(sampl.kernLogtheta(:,d), bins);
  Z = ( (max(bins)-min(bins))/(2*N) )*sum(h(1) + 2*h(2:end-1) + h(end));
  plot(x, h/Z, 'k-','linewidth',2);
  plot(x, normpdf(x,mu(d), sqrt(vars(d)) ), 'r--','linewidth',2);
  if d < 14
     name = [outdir 'boston_lengthscale' num2str(d) '_' diagfull];
     xlabel(['$$\log(\ell_{' num2str(d) '}^2)$$'] ,'interpreter', 'latex','fontsize',20);
  else
     name = [outdir 'boston_sigma2f' '_' diagfull];
     xlabel('$$\log(\sigma_f^2)$$' ,'interpreter', 'latex','fontsize',20);
  end
  ylabel('Density value','fontsize',20);
  set(gca,'fontsize',20);
  box on;    
  if exist(outdir)
     print('-depsc2', '-r300', name);
     cmd = sprintf('epstopdf %s', [name '.eps']);
     system(cmd);
  end
end
 
bins2 = linspace(min(sampl.likLogtheta), max(sampl.likLogtheta), N+1);
[h2, x2] = hist(sampl.likLogtheta, bins2);
figure;
set(gcf, 'Renderer', 'Painters');
hold on; 
Z2 = ( (max(bins2)-min(bins2))/(2*N) )*sum(h2(1) + 2*h2(2:end-1) + h2(end));
plot(x2,  h2/Z2, 'k-','linewidth',2);
plot(x2, normpdf(x2, mu(end), sqrt(vars(end)) ), 'r--', 'linewidth',2);
xlabel('$$\log(\sigma^2)$$' ,'interpreter', 'latex','fontsize',20);
ylabel('Density value','fontsize',20);
set(gca,'fontsize',20);
box on;
name = [outdir 'boston_sigma2' '_' diagfull];
if exist(outdir)
   print('-depsc2', '-r300', name);
   cmd = sprintf('epstopdf %s', [name '.eps']);
   system(cmd);
end

disp('Testing the model and compare MCMC, variational and ML Type II prediction.'); 

Ytrain = y; Xtrain = X;
Ytest = ystar; Xtest = Xstar;
% Prediction for the ML GP (standard  hyperparameters training)
logtheta0 = zeros(D,1);
logtheta0(D-1) = 0.5*log(var(Ytrain));
logtheta0(D-1) = 0.5*log(var(Ytrain)/6);
tic;
logtheta = minimize(logtheta0, 'gpr', -500, covfunc, Xtrain, Ytrain);
timetakenML=toc;

[fstar S2] = gpr(logtheta, covfunc, Xtrain, Ytrain, Xtrain);
res = fstar-Ytrain;  % residuals
mseMLtr = mean(res.^2);
pllMLtr = -0.5*mean(log(2*pi*S2)+res.^2./S2);

[fstar S2] = gpr(logtheta, covfunc, Xtrain, Ytrain, Xtest);
res = fstar-Ytest;  % residuals
mseMLts = mean(res.^2);
pllMLts = -0.5*mean(log(2*pi*S2)+res.^2./S2);


% Training error measures (you don't really display those, but just compute them for completeness.')
T = 1000;
nstar = size(Xtrain,1);
mustar = zeros(nstar, 1);
tmp = zeros(nstar, T);
for s=1:T
  if size(C,2) == 1  
     theta = C.*randn(D,1) + mu; 
  else
     theta = C*randn(D,1) + mu;  
  end
  [fstar S2] = gpr(0.5*theta, covfunc, Xtrain, Ytrain, Xtrain);
  mustar = mustar + fstar;
  diff = fstar - Ytrain; 
  tmp(:,s) = - 0.5*log(2*pi*S2) - 0.5*((diff.^2)./S2); 
end
g = max(tmp,[],2); 
pllVartr = - log(T) + g + log(sum(exp( tmp - repmat(g,1,T) ), 2));
pllVartr = mean(pllVartr);
mustar = mustar/T;
res = mustar-Ytrain;  % residuals
mseVartr = mean(res.^2);


% Prediction for the stochastic variational method
T = 1000;
nstar = size(Xtest,1);
mustar = zeros(nstar, 1);
tmp = zeros(nstar, T);
for s=1:T
  if size(C,2) == 1  
     theta = C.*randn(D,1) + mu; 
  else
     theta = C*randn(D,1) + mu;  
  end
  [fstar S2] = gpr(0.5*theta, covfunc, Xtrain, Ytrain, Xtest);
  mustar = mustar + fstar;
  diff = fstar - Ytest; 
  tmp(:,s) = - 0.5*log(2*pi*S2) - 0.5*((diff.^2)./S2); 
end
g = max(tmp,[],2); 
pllVarts = - log(T) + g + log(sum(exp( tmp - repmat(g,1,T) ), 2));
pllVarts = mean(pllVarts);
mustar = mustar/T;
res = mustar-Ytest;  % residuals
mseVarts = mean(res.^2);

% Prediction for MCMC
T = 1000;
nstar = size(Xtrain,1);
step = 10;
mustar = zeros(nstar, 1);
tmp = zeros(nstar, T);
for s=1:T  
  theta = [sampl.kernLogtheta((s-1)*step+1,:), sampl.likLogtheta((s-1)*step+1)]'; 
  [fstar S2] = gpr(0.5*theta, covfunc, Xtrain, Ytrain, Xtrain);
  mustar = mustar + fstar;
  diff = fstar - Ytrain; 
  tmp(:,s) = - 0.5*log(2*pi*S2) - 0.5*((diff.^2)./S2);
end
g = max(tmp,[],2); 
pllMCMCtr = - log(T) + g + log(sum(exp( tmp - repmat(g,1,T) ), 2));
pllMCMCtr = mean(pllMCMCtr);
mustar = mustar/T;
res = mustar-Ytrain;
mseMCMCtr = mean(res.^2);


% Prediction for MCMC
T = 1000;
nstar = size(Xtest,1);
step = 10;
mustar = zeros(nstar, 1);
tmp = zeros(nstar, T);
for s=1:T  
  theta = [sampl.kernLogtheta((s-1)*step+1,:), sampl.likLogtheta((s-1)*step+1)]'; 
  [fstar S2] = gpr(0.5*theta, covfunc, Xtrain, Ytrain, Xtest);
  mustar = mustar + fstar;
  diff = fstar - Ytest; 
  tmp(:,s) = - 0.5*log(2*pi*S2) - 0.5*((diff.^2)./S2);
end
g = max(tmp,[],2); 
pllMCMCts = - log(T) + g + log(sum(exp( tmp - repmat(g,1,T) ), 2));
pllMCMCts = mean(pllMCMCts);
mustar = mustar/T;
res = mustar-Ytest;
mseMCMCts = mean(res.^2);


disp(['SMSE-ts: GP with ML -- VAR GP --- MCMC GP']);
disp([mseMLts/var(Ytest), mseVarts/var(Ytest), mseMCMCts/var(Ytest)]);

disp(['NLPD-ts: GP with ML -- VAR GP --- MCMC GP']);
disp([-pllMLts, -mean(pllVarts), -mean(pllMCMCts)]);


disp(['SMSE-tr: GP with ML -- VAR GP --- MCMC GP']);
disp([mseMLtr/var(Ytrain), mseVartr/var(Ytrain), mseMCMCtr/var(Ytrain)]);

disp(['NLPD-tr: GP with ML -- VAR GP --- MCMC GP']);
disp([-pllMLtr, -mean(pllVartr), -mean(pllMCMCtr)]);


%save(['dem' dataName '.mat'], 'timetakenVar','timetakenML', 'mu', 'C','mseVartr','mseMLtr', 'mseMCMCtr', 'pllVartr', 'pllMLtr', 'pllMCMCtr',...
%    'mseVarts','mseMLts', 'mseMCMCtr', 'pllVarts', 'pllMLts', 'pllMCMCts');
