This MATLAB software implements the doubly stochastic variational 
inference (DSVI) method described in the following paper: 

Michalis K. Titsias and Miguel Lazaro-Gredilla. 
Doubly Stochastic Variational Bayes for non-Conjugate Inference.
Proceedings of the 31st International Conference on Machine
Learning (ICML), Beijing, China, 2014. JMLR: W&CP volume 32.

The main routines are the functions dsvi.m (standard DSVI) 
and dsvi_sparseARD.m (DSVI for automatic variable selection). 
For further details see the documentation in the former functions 
as well as the provided demos.  

The software of Rasmussen and  Williams (2006) that is used in the 
GP hyperparameter learning experiments has been included for 
convenience (directory toolbox_gpml). 

You can freely use this code for academic or research purposes 
as long as you refer to the above publication.  

Copyright (c) Michalis Titsias and Miguel Lazaro-Gredilla (2014)

