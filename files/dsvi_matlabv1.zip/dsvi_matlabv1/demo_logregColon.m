clear;
close all;
outdir= '../../diagrams/';
doplot = 1;
saveres = 0;
dataName = 'Colon';
randn('seed',1);
rand('seed',1);

%-- To run this demo you need to load the data based on libsvm-3.17/matlab/
%-- software from the webpage
%-- (http://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/). I.e. you will need 
%-- to download this software and then use the following commands 
%
% addpath ../../../../Software/LIBSVM3.17/libsvm-3.17/matlab/  %  just helps to read the data 
% [Y, X]  = libsvmread('../../../../DATA/colon-cancer');

% Here we have already done the above and we have stored the data in  
% matlab data file for convenience 
load ../../../../DATA/colon.mat;


[n, D] = size(X);

% Add an extra column in X with ones for the bias term in 
% logistic regression 
X = [ones(n,1), full(X)];  

Class1 = find(Y==1); 
Class2 = find(Y==-1); 
N1 = length(Class1);
N2 = length(Class2); 
N1tr = 12; 
N2tr = 30;

ch1 = randperm(N1); 
ch2 = randperm(N2); 
ch = [ch1(1:N1tr), ch2(1:N2tr)];

Ytr = [Y(ch1(1:N1tr)); Y(ch2(1:N2tr))];
Xtr = [X(ch1(1:N1tr),:); X(ch2(1:N2tr),:)];

Ntr = size(Xtr,1); 

Yts = [Y(ch1(N1tr+1:end)); Y(ch2(N2tr+1:end))];
Xts = [X(ch1(N1tr+1:end),:); X(ch2(N2tr+1:end),:)];

Nts = size(Xts,1);

% log likelihood function
loglik.name = @log_logreg;     % logistic regression log likelihood
loglik.inargs{1} = Xtr;        % input data 
loglik.inargs{2} = Ytr;        % binary outputs encoded as -1,1
loglik.inargs{3} = (Ytr+1)/2;  % binary outputs encoded as 0,1 (just for convenience)

dec = 0.95; 

options = zeros(1,10); 
options(1) = 5000;    % number of iterations per stage
options(2) = 0.05/size(Xtr,1);   % initial value of the learning rate

mu = zeros(D+1,1);
C = 0.1*ones(D+1,1);

iters = 20;  % number of optimization stages (each stage takes options(1) iterations)

F = zeros(1,iters*options(1));
ops = options; 
tic;
for it=1:iters
%      
   [Ftmp, mu, C] = dsvi_sparseARD(mu, C, loglik, options);
    
   F((it-1)*options(1)+1:it*options(1)) = Ftmp;
   
   % decrease the learning rate for the next stage 
   options(2) = dec*options(2);
   
   fprintf('Iters=%d, Ftmp=%f\n',it*options(1), mean(Ftmp));
%   
end
timetakenVar = toc;


vars = C.*C; 

% LOWER BOUND
if doplot == 1
  mF = zeros(1,length(F));
  W = 200;
  for n=1:length(F)
    st = n-W+1;
    st(st<1)=1;
    mF(n) = mean(F(st:n));
  end
  figure;
  plot(mF,'b', 'linewidth',1.5);
  xlabel('Iterations','fontsize',20);  
  ylabel('Lower bound','fontsize',20);
  set(gca,'fontsize',20); 
  if exist(outdir)
     print('-depsc2', '-r300', [outdir 'colon_lowerBound']);
     cmd = sprintf('epstopdf %s', [outdir 'colon_lowerBound.eps']);
     system(cmd);
  end 

  % sparsity 
  figure;
  plot(1:D, mu(2:end), 'b', 'linewidth', 1.5);
  xlabel('Variable index','fontsize',20);
  ylabel('Mean of the Var. Distr.','fontsize',20);
  set(gca,'fontsize',20);
  range = max(mu) - min(mu);
  axis([0 length(mu)+1 (min(mu)-0.02*range) (max(mu)+0.02*range)])
  if exist(outdir)
    print('-depsc2', '-r300', [outdir 'colon_selection']);
    cmd = sprintf('epstopdf %s', [outdir 'colon_selection.eps']);
    system(cmd);
  end
 
  % sparsity 
  figure;
  lambda =  mu(2:end).^2 + vars(2:end);
  plot(1:D, lambda, 'b', 'linewidth', 1.5);
  xlabel('Variable index','fontsize',20);
  ylabel('Optimal prior variances','fontsize',20);
  set(gca,'fontsize',20);
  range = max(lambda) - min(lambda);
  axis([0 length(lambda)+1 (min(lambda)-0.02*range) (max(lambda)+0.02*range)])
  if exist(outdir)
    print('-depsc2', '-r300', [outdir 'colon_selectionLambda']);
    cmd = sprintf('epstopdf %s', [outdir 'colon_selectionLambda.eps']);
    system(cmd);
  end
end 

Str = sigmoid(Xtr*mu);
Sts = sigmoid(Xts*mu);
fprintf('Colon, Train error: %d/%d\n',sum(abs([(Ytr+1)/2 - round(Str)])), Ntr);
fprintf('Colon, Test error: %d/%d\n',sum(abs([(Yts+1)/2 - round(Sts)])), Nts);

%if saveres == 1
%  save(['Res' dataName '.mat'], 'timetakenVar','mu', 'C','F');
%end

